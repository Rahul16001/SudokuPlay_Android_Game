package com.example.sudokuplay;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.TextView;

public class Rules extends AppCompatActivity {

    TextView rule1,rule2,rule3,congo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rules);

        rule1 = findViewById(R.id.rule1);
        rule2 = findViewById(R.id.rule2);
        rule3 = findViewById(R.id.rule3);
        congo = findViewById(R.id.congo);

        Handler handle = new Handler();

        handle.postDelayed(new Runnable() {
            @Override
            public void run() {
                rule1.setVisibility(View.VISIBLE);
            }
        },1000);

        handle.postDelayed(new Runnable() {
            @Override
            public void run() {
                rule2.setVisibility(View.VISIBLE);
            }
        }, 2000);

        handle.postDelayed(new Runnable() {
            @Override
            public void run() {
                rule3.setVisibility(View.VISIBLE);
            }
        },3000);

        handle.postDelayed(new Runnable() {
            @Override
            public void run() {
                congo.setVisibility(View.VISIBLE);
            }
        },4000);

    }

    public void onStartClick(View view)
    {
        SudokuHome.media.start();
        Intent intent = new Intent(this,SudokuData.class);
        startActivity(intent);
    }
}