package com.example.sudokuplay;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;

public class SudokuHome extends AppCompatActivity {

    static MediaPlayer media;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sudoku_home);
    }

    public void onPlay(View view)
    {
        media = MediaPlayer.create(getApplicationContext(),R.raw.button_click);
        media.start();

        Intent intent = new Intent(this,Rules.class); // directing towards rules section...
        startActivity(intent);
    }
}