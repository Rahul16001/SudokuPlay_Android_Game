package com.example.sudokuplay;
import static com.example.sudokuplay.SudokuData.userFillList;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class Play extends AppCompatActivity {

    SudokuBoard sudokuBoard;
    Button getAnswer,submit,goBack;

    Handler handler;
    Runnable run;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sudokuBoard  = findViewById(R.id.sudokuBoard);
        getAnswer = findViewById(R.id.getAnswer);
        submit = findViewById(R.id.submit);
        goBack = findViewById(R.id.goBack);

        handler = new Handler();

        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(Play.this, "Select cell from above grid and Press number to put inside..",Toast.
                        LENGTH_LONG).show();
            }
        },2000);

        run  = new Runnable() {
            @Override
            public void run() {
                Toast.makeText(Play.this, "Stuck Press Generate Answer Button", Toast.LENGTH_SHORT)
                        .show();
                SudokuHome.media.start();
            }
        };

        handler.postDelayed(run,20000);// a message will appear after 20 seconds of playing to generate answer if want..

    }

    public void buttonPressed(View view) // this function handles use input and refreshes drawing canvas
    {
       String num = view.getTag().toString();
       int value= Integer.parseInt(num);
       SudokuModel.setUserValue(value);
       sudokuBoard.invalidate();
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(run);
    }

    public void onBoardSubmit(View view)  // this function checks if after submit tabe is completed or not...
    {
        for(int[] row : SudokuModel.getBoard())
        {
            for(int x : row)
            {
                if(x == 0)
                {
                    Toast.makeText(getApplicationContext(),"Complete Table First....",Toast.LENGTH_SHORT).show();
                    return;
                }
            }
        }
        checkTable(); // if table is complete then run checkTable function

    }

    static boolean isValid(int x, int y, int value)
    {
        for(int i=0;i<9;i++)
        {
            if(i!=y && SudokuModel.getBoard()[x][i] == value) return false;
        }

        for(int i=0;i<9;i++)
        {
            if(x!=i && SudokuModel.getBoard()[i][y] == value) return false;
        }

        int row = x - x%3;
        int col = y - y%3;

        for(int i=row;i<row+3;i++)
        {
            for(int j = col;j<col+3;j++)
            {
                if(i!=x && j!=y && SudokuModel.getBoard()[i][j] == value) return false;
            }
        }

        return true;
    }

    public void checkTable() // this checks whether each cell is fulfilling sudoku condition or not...
    {
        for(int i=0;i<9;i++)
        {
            for(int j=0;j<9;j++)
            {
                if(!isValid(i,j,SudokuModel.getBoard()[i][j]))
                {
                  Toast.makeText(getApplicationContext(),"Wrong Answer",Toast.LENGTH_SHORT).show();
                  return ;
                }
            }
        }

       Toast.makeText(getApplicationContext(),"You Won",Toast.LENGTH_SHORT).show();
    }

    public void SolveButton(View view)
    {

//        Toast.makeText(getApplicationContext(),""+originalFillList.size()+" "+SudokuModel.getSet().size(),Toast.LENGTH_SHORT).show();
//        sudokuBoard.invalidate();

        for(ArrayList<Integer> element : userFillList) // this is resetting any user change ....
        {
            SudokuModel.getBoard()[element.get(0)][element.get(1)] = 0;
        }

        SolveSudoku(userFillList,0);
        sudokuBoard.invalidate();

        getAnswer.setVisibility(View.INVISIBLE);
        submit.setVisibility(View.INVISIBLE);
        goBack.setVisibility(View.VISIBLE);


    }

    public void goHome(View view) // this function is to go back to home page
    {
        goBack.setVisibility(View.INVISIBLE);
        handler.removeCallbacks(run);
        Intent intent = new Intent(this,SudokuHome.class);
        startActivity(intent);
    }

    public boolean SolveSudoku(ArrayList<ArrayList<Integer>> userFillList, int index) // this function is used to generate answer
    {
        if(index == userFillList.size())
        {
            return true;
        }

        int x = userFillList.get(index).get(0);
        int y = userFillList.get(index).get(1);

        for(int i = 1;i<=9;i++)
        {
            if(isValid(x,y,i))
            {
                SudokuModel.getBoard()[x][y] = i;
                if(SolveSudoku(userFillList,index+1)) return true;
                SudokuModel.getBoard()[x][y] = 0;
            }
            sudokuBoard.invalidate();
        }
        return false;
    }

}
