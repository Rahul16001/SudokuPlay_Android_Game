package com.example.sudokuplay;

import java.util.HashSet;
import java.util.Set;

public class SudokuModel {

    static public int [][]board;

    static boolean isValid;

    public static Set<Pair> getSet() {
        return set;
    }

    public static void setSet(Set<Pair> set) {
        SudokuModel.set = set;
    }

    static public Set<Pair> set;

    public static int getUserValue() {
        return userValue;
    }

    public static void setUserValue(int userValue) {
        SudokuModel.userValue = userValue;
    }

    static int userValue;

    public static boolean getIsValid() {
        return isValid;
    }

    public static void setIsValid(boolean isValid) {
        SudokuModel.isValid = isValid;
    }

    public static int getSelectedRow() {
        return selectedRow;
    }

    public static void setSelectedRow(int selectedRow) {
        SudokuModel.selectedRow = selectedRow;
    }

    public static int getSelectedColumn() {
        return selectedColumn;
    }

    public static void setSelectedColumn(int selectedColumn) {
        SudokuModel.selectedColumn = selectedColumn;
    }

    static int selectedRow;
    static int selectedColumn;

    SudokuModel()
    {
        board = new int[9][9];
        set  = new HashSet<>();
        setSelectedColumn(-1);
        setSelectedRow(-1);
        setUserValue(-1);
        setIsValid(false);
    }

    static int[][] getBoard()
    {
        return board;
    }

}
