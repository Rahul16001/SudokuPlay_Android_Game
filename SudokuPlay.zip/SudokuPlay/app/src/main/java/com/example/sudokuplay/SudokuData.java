package com.example.sudokuplay;

import static com.example.sudokuplay.SudokuModel.set;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class SudokuData extends AppCompatActivity {
    static public ArrayList<ArrayList<Integer>> userFillList;
    static private int count = 40;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.entry);
        new SudokuModel(); // creating anonymous instance of sodoKuModel so values get initialized through constructor.....

        userFillList = new ArrayList<>();
        count = 40;
        SudokuModel.getSet().clear();
        for(int []row : SudokuModel.getBoard())  Arrays.fill(row,0);


        for(int i=0;i<9;i++)
        {
            for(int j=0;j<9;j++)
            {
                ArrayList<Integer> temp = new ArrayList<>();
                temp.add(i);
                temp.add(j);
                userFillList.add(temp);    //adding indices to userFillList so that board can be filled...
                                           // this is just to get index while iterating over board...can be skipped...
            }
        }
        fillBoard(0); // calling function to fillBoard...
        setBoard();// making vacant space in board for user to give input....

        func();// intent to start game after setup


    }

    public void func()
    {
        Intent intent = new Intent(this, Play.class);
        startActivity(intent);
    }

    static boolean isValid(int x, int y, int value) // checking if value is possible for given position
    {
       for(int i=0;i<9;i++)
       {
           if(SudokuModel.getBoard()[x][i] == value) return false;
       }

       for(int i=0;i<9;i++)
       {
           if(SudokuModel.getBoard()[i][y] == value) return false;
       }

       int row = x - x%3;
       int col = y - y%3;

       for(int i=row;i<row+3;i++)
       {
           for(int j = col;j<col+3;j++)
           {
               if(SudokuModel.getBoard()[i][j] == value) return false;
           }
       }

       return true;
    }

    public boolean fillBoard(int index) // fill board function to get right board initiallly...
    {
        if(userFillList.size() == index) return true;

        int x = userFillList.get(index).get(0);
        int y = userFillList.get(index).get(1);

        for(int i=1;i<=9;i++)
        {
            if(isValid(x,y,i))
            {
                SudokuModel.getBoard()[x][y] = i;
                if(fillBoard(index+1)) return true;
                SudokuModel.getBoard()[x][y] = 0;
            }
        }

        return false;
    }

    static public void setBoard() // now making some vacant space in board and storing it into userFillList....
    {
        userFillList.clear();
        while(count>=0)
        {
            int x = (int) ((Double) Math.random()*9.0);
            int y = (int) ((Double) Math.random()*9.0);

            Pair obj = new Pair(x,y);

            if(!SudokuModel.getSet().contains(obj))
            {
                ArrayList<Integer> temp = new ArrayList<>();
                temp.add(x);
                temp.add(y);
                userFillList.add(temp);
                SudokuModel.getBoard()[x][y] = 0;
                count--;
                SudokuModel.getSet().add(obj);
            }
        }
    }
}
class Pair
{
    int x,y;
    Pair(int x,int y)
    {
        this.x = x;
        this.y = y;
    }

    @Override
    public boolean equals(@Nullable Object obj) {
        if(this == obj) return true;

        Pair other = (Pair)obj;
        return other.x == x && other.y == y;
    }

    @Override
    public int hashCode() {
        return 31 * (x+y);
    }
}
