package com.example.sudokuplay;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

import java.io.IOException;
import java.util.ArrayList;

import androidx.annotation.Nullable;

public class SudokuBoard extends View {

    private final int boardColor;
    private final int textColor;
    private final Paint textPaint = new Paint();
    private final Paint lightPaint = new Paint();

    private final Paint boardPaint = new Paint();
    private int cellSize;

    static int highX = -1;
    static int highY = -1;



    public SudokuBoard(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);

        TypedArray atri = context.getTheme().obtainStyledAttributes(attrs,R.styleable.SudokuBoard,0,0);
        //here accessing constants declared for custom view in attrs.xml
        try {
            boardColor = atri.getInteger(R.styleable.SudokuBoard_board_color,0);
            textColor = atri.getInteger(R.styleable.SudokuBoard_textColor,0);
        }
        finally {
            atri.recycle();
        }


    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);

        // finding appropriate dimension for sodoku grid
        int dimension = Math.min(this.getMeasuredWidth(),this.getMeasuredHeight());

        cellSize = dimension/9;

        setMeasuredDimension(dimension,dimension);

    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        lightPaint.setStyle(Paint.Style.FILL);
        lightPaint.setColor(Color.YELLOW);
        lightPaint.setAlpha(50);
        lightPaint.setAntiAlias(true);

        boardPaint.setColor(boardColor);
        boardPaint.setStyle(Paint.Style.STROKE);
        boardPaint.setStrokeWidth(6);
        boardPaint.setAntiAlias(true);

        textPaint.setColor(textColor);
        textPaint.setStyle(Paint.Style.STROKE);
        textPaint.setStrokeWidth(5);
        textPaint.setAntiAlias(true);
        int txtSize = (int) (cellSize * 0.75);
        textPaint.setTextSize(txtSize);

        canvas.drawRect(0,0,getMeasuredWidth(),getMeasuredHeight(),boardPaint);
        drawBoard(canvas);
        if(SudokuModel.getUserValue()!= -1)
            userInput(SudokuModel.getSelectedRow(),SudokuModel.getSelectedColumn(),SudokuModel.getUserValue());
        highLight(canvas);
        putNumbers(canvas);
    }

    public void userInput(int row, int col,int userValue) // handling user input
    {
        int xPos = col;  // here col means moving towards right and row means moving toward down
        int yPos = row;

        boolean go = false;

        ArrayList<Integer> temp = new ArrayList<>();
        temp.add(xPos);
        temp.add(yPos);
        if(SudokuData.userFillList.contains(temp)) go = true;

        if(go && SudokuModel.getIsValid() && row != -1 && col !=-1 && userValue != -1)
        {

            if(SudokuModel.getBoard()[xPos][yPos] == userValue)
            {
                SudokuModel.getBoard()[xPos][yPos] = 0;
            }
            else
            {
                SudokuModel.getBoard()[xPos][yPos] = userValue;
            }
        }
        SudokuModel.setIsValid(false);
        SudokuModel.setSelectedRow(-1);
        SudokuModel.setSelectedColumn(-1);
        SudokuModel.setUserValue(-1);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) // function to handle touch event....
    {

        int x = (int) (event.getX()/cellSize);
        int y = (int) (event.getY()/cellSize);

        int action = event.getAction();

        if(action == MotionEvent.ACTION_DOWN)
        {
                highX = y; // highX is given y because y is column number horizontally right...
                highY = x; // highY is given x because x is row number vertically down..
            SudokuModel.setIsValid(true);
            SudokuModel.setSelectedRow(x);
            SudokuModel.setSelectedColumn(y);
            this.invalidate();
        }

        return true;
    }

    public void highLight(Canvas canvas)
    {
        if(highX != -1)
        {
            canvas.drawRect((highY+1)*cellSize,(highX+1)*cellSize,highY*cellSize,highX*cellSize,
                    lightPaint);
        }
        highY = highX = -1;
    }

    void thickLine()
    {
        boardPaint.setColor(Color.BLUE);
        boardPaint.setStyle(Paint.Style.STROKE);
        boardPaint.setStrokeWidth(30);
        boardPaint.setAntiAlias(true);
    }

    void thinLine()
    {
        boardPaint.setColor(boardColor);
        boardPaint.setStyle(Paint.Style.STROKE);
        boardPaint.setStrokeWidth(6);
        boardPaint.setAntiAlias(true);
    }

    void putNumbers(Canvas canvas)// function to put numbers inside the grid from board array while refersing canvas..
    {
        for(int row=0;row<9;row++)
        {
            for(int col=0;col<9;col++)
            {
                if(SudokuModel.getBoard()[row][col] != 0)
                {
                    int x = cellSize * col + ((int)(cellSize*0.25));
                    int y = cellSize * row + cellSize - ((int)(cellSize*0.25));

                    String num = String.valueOf(SudokuModel.getBoard()[row][col]);

                    canvas.drawText(num,x,y,textPaint);
                }
            }
        }
    }

    public void drawBoard(Canvas canvas) // function to draw horizontal and vertical lines on board...
    {
        for(int c = 0;c<10;c++)
        {
            if(c % 3 == 0)
            {
                thickLine();
            }
            else  thinLine();
            canvas.drawLine(cellSize*c,0,cellSize*c,getMeasuredHeight(),boardPaint);
        }

        for(int r =0;r<10;r++)
        {
            if(r % 3 == 0)
            {
                thickLine();
            }
            else  thinLine();
            canvas.drawLine(0,cellSize*r,getMeasuredWidth(),cellSize*r,boardPaint);
        }

        thinLine();
    }


}
